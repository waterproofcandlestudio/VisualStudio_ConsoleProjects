﻿using System;

namespace ListasDoblementeEnlazadas
{
    class Program
    {
        static void Main(string[] args)
        {
            Lista lista = new Lista();

            bool asdasdasd = false;

            Console.WriteLine("Buenos dias, inserte números a la lista hasta que quiera parar, para ello escriba \"777\"");
            do
            {
                lista.InsertarElemento(); 
            }
            while (lista.datoAInsertar != 777);

            lista.MostrarLista();

            lista.EliminarLista(); 

            lista.MostrarLista();
            
            do
            {
                Console.WriteLine("¿Desea borrar algún elemento de la lista?(Y/N): ");
                string decision = Console.ReadLine();

                if (decision == "Y")
                {
                    lista.EliminarElemento();
                    lista.MostrarLista();

                }
                else if (decision == "N")
                {
                    Console.WriteLine("Chao, chao");
                    asdasdasd = true;
                }
                else
                {
                    Console.WriteLine("No has escrito algo bien aquí socio"); 
                }
            }
            while (asdasdasd == false); 

            Console.ReadKey(); 


        }
    }
}
