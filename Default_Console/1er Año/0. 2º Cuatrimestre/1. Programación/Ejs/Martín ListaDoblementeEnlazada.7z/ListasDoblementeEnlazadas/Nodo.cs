﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ListasDoblementeEnlazadas
{
    class Nodo
    {
        public int data;
        public Nodo siguiente;
        public Nodo anterior; 

        public Nodo(int v)
        {
            data = v;
            siguiente = null;
            anterior = null; 

        }

    }
}
