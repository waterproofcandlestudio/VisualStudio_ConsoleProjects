﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ListasDoblementeEnlazadas
{
    class Lista
    {
        Nodo nodoDeAcceso;

        public int datoAInsertar;

        public bool ListaVacia()
        {
            if(nodoDeAcceso == null)
            {
                return true;
            }
            else
            {
                return false; 
            }
        }

        public void InsertarElemento()
        {

            Console.Write("Elemento que desee insertar: ");
            datoAInsertar = int.Parse(Console.ReadLine());

            //Variables auxiliares
            Nodo nodoAInsertar = new Nodo(datoAInsertar); 

            if(ListaVacia())
            {
                //Si la lista está vacia, entonces nuestro nuevo nodo será el nodo de Acceso, y sus referencias apuntarán a null, ya que no hay nada más.

                nodoDeAcceso = nodoAInsertar;
                nodoAInsertar.siguiente = null;
                nodoAInsertar.anterior = null;
            }
            else
            {
                //Insertar un nodo en una lista no ordenada, detrás simplemente del nodo de acceso, el cual es el primero

                //1- Nuestro nodo siguiente tiene que ser el que era antes el del nodo de acceso, para tomar su puesto
                nodoAInsertar.siguiente = nodoDeAcceso.siguiente;
                //2- Hacemos que el nodo de acceso nos apunte a nosotros como siguiente
                nodoDeAcceso.siguiente = nodoAInsertar;
                //3- Apuntamos de vuelta al nodo de acceso
                nodoAInsertar.anterior = nodoDeAcceso;
                //4- Hacemos que el siguiente a nosotros nos apunte como anteriores si el siguiente no es null, ya que eso implicaria que es el final de la lista
                if(nodoAInsertar.siguiente != null)
                {
                    nodoAInsertar.siguiente.anterior = nodoAInsertar;
                }

            }

        }

        public void MostrarLista()
        {
            Nodo indice;

            Console.WriteLine("******Lista******");

            if (ListaVacia())
            {
                Console.WriteLine("La lista está vacia"); 
            }
            else
            {
                indice = nodoDeAcceso;

                Console.WriteLine("Dato: " + indice.data); 

                while(indice.siguiente != null)
                {
                    indice = indice.siguiente;

                    Console.WriteLine("Dato: " + indice.data);

                }

            }
        }

        public void EliminarElemento()
        {
            //Recogemos el número que queremos borrar y lo guardamos en un nodo

            int elementoAEliminar;

            Console.Write("Elemento que desee eliminar: ");
            elementoAEliminar = int.Parse(Console.ReadLine()); 

            Nodo nodoAEliminar = new Nodo(elementoAEliminar);
            Nodo auxiliar; 

            if(ListaVacia())
            {
                Console.WriteLine("La lista está vacia, no hay datos que borrar");
            }
            else
            {
                //Anclamos el nodo auxiliar al nodo de acceso para tener un punto de referencia desde el que partir 
                auxiliar = nodoDeAcceso; 

                //Desde ese punto comenzamos a buscar el nodo que queremos eliminar, hasta que no lo encontremos el auxiliar seguirá avanzando
                while(auxiliar.siguiente != null && auxiliar.data != nodoAEliminar.data)
                {
                    auxiliar = auxiliar.siguiente;
                }

                //Una vez que lo encuentre, primero checkeará si el nodo que queremos borrar es el nodo de acceso, de ser así...
                if(auxiliar == nodoDeAcceso)
                {
                    //... Comprobamos que no este en la ultima posición, si está, entonces lo movemos uno para atras, sino uno para alante, asi nunca perdemos el nodo de acceso
                    if(nodoDeAcceso.siguiente != null)
                    {
                        nodoDeAcceso = nodoDeAcceso.siguiente;
                    }
                    else
                    {
                        nodoDeAcceso = nodoDeAcceso.anterior; 
                    }
                }
                //Si no es el nodo de acceso, entonces lo que hacemos es paso por paso ir redirigiendo las conexiones de los dos que nos rodean hacia otros nodos, saltandonos en el proceso
                if(auxiliar.anterior != null)
                {
                    //Hacemos que el anterior nodo en vez de apuntarnos a nosotros de siguientes, lo haga al que lo haciamos nosotros, saltándonos a nosotros.
                    auxiliar.anterior.siguiente = auxiliar.siguiente; 
                }
                else if(auxiliar.siguiente != null)
                {
                    //Lo mismo pero con la referencia anterior
                    auxiliar.siguiente.anterior = auxiliar.anterior; 
                }

                //Con esto el nodo se queda sin referencias de siguiente o anterior, por lo que tendremos que apuntarlos a null para destruirlo completamente.

                //Desenganchamos el nodo que queremos borrar
                auxiliar.anterior = null;
                auxiliar.siguiente = null; 

            }

        }

        public void EliminarLista()
        {
            if(ListaVacia())
            {
                Console.WriteLine("La lista está vacia");
            }
            else
            {
                //Arrastramos el nodo de acceso hasta que este sea nulo, es decir, lo llevamos al final arrastrando el resto de números detras nuestra

                while(nodoDeAcceso != null)
                {
                    nodoDeAcceso = nodoDeAcceso.siguiente; 
                }
            }
        }

    }
}
